Culture Collection 1.3
Desk & Bench — Ugur Comlekcioglu

GETTING STARTED
1. Extract the ZIP into a permanent folder.
2. Open culture-collection.html in Chrome, Edge or Firefox.
3. On the Groups tab, add your own groups (for example clinical, wastewater, textile factory).
4. Add a culture, then attach one or more stock vials to it.
5. Download a JSON backup regularly from the Backups tab.

WHERE YOUR DATA IS STORED
Records are kept in the database of the browser you open the file in, not in the HTML file.
Keep using the same file location and the same browser. Download a JSON backup before you
move or rename the file, update the app or clear browser data. Copying the HTML file does not
copy your records. Do not use private browsing windows.

MOVING TO ANOTHER COMPUTER
Open the app on the new computer and use Backups > Restore JSON backup. Restoring replaces the
whole collection; it does not merge records. CSV files are for reports only and cannot be restored.

REMINDERS
- Settings controls the viability check interval (1–120 calendar months, default 6).
  Due vials are listed on Overview. Record a check date to move the next reminder forward.
- After every change, a bar at the top shows how many changes you have made since your last
  JSON backup, with a button to download a new one. It disappears once you have a fresh backup.

NOT INCLUDED IN THIS VERSION
There is no cloud sync or Firebase connection. DNA, sequence, plasmid and gene modules are not
included. Use sample codes instead of patient identifiers.

Feedback: https://github.com/ugurlab/culture-collection/issues
Instrument Sans font: see FONT-LICENSE.txt.

LICENCE
Culture Collection is open source under the MIT License (see LICENSE.txt). You may use, change and
share it, including in your own projects, as long as you keep the copyright notice and the licence
text, which credit the original author.

CHANGES IN 1.2
- A backup bar appears after every change until you download a new JSON backup
  (replaces the six-month backup reminder).
- Released under the MIT License.

CHANGES IN 1.1
- English only.
- Search ignores accents and dotted/dotless i (for example "izmir" finds "İzmir").
- Stock search also covers temperature, quantity, preparation date and notes.
- Cultures and stock vials can be deleted.
- Warning when a position is already used by another vial.
- Six-month reminders for old stock vials and for backups.

Version 1.3
Deleting a culture or vial moves it to Trash. Restore it there; nothing is purged automatically. Culture restoration preserves linked vials, while separately trashed vials remain in Trash. Codes remain reserved.
Settings: choose a viability check interval of 1–120 calendar months (default 6). Record Last viability check or click Mark checked today, then Save. The next reminder uses the later of preparation and last check.
JSON includes Trash, settings and check dates. CSV reports exclude Trash. Version 1.3 reads older backups, but its new schema 2 backups require 1.3 or newer. Back up before upgrading.
