Kültür Koleksiyonu / Culture Collection 1.0
Desk & Bench — Uğur Çömlekcioğlu / Ugur Comlekcioglu

TÜRKÇE
1. ZIP dosyasını kalıcı bir klasöre çıkar.
2. culture-collection.html dosyasını Chrome, Edge veya Firefox ile aç.
3. Gruplar ekranında kendi grup adlarını ekle (klinik, atık su, tekstil fabrikası vb.).
4. Kültür ekle; ardından aynı kültüre bir veya daha fazla stok tüpü bağla.
5. Yedekleme ekranından düzenli JSON yedeği indir.

Veriler HTML dosyasına değil, açtığın tarayıcının yerel veritabanına kaydedilir. Aynı dosyayı aynı konumda ve aynı tarayıcıda kullan. Dosyayı taşımadan, yeniden adlandırmadan, uygulamayı güncellemeden veya tarayıcı verilerini temizlemeden önce JSON yedeği al. HTML dosyasını kopyalamak verileri kopyalamaz. Gizli pencere kullanma.

Başka bilgisayara taşırken JSON yedeğini yeni bilgisayardaki Yedekleme > JSON yedeği yükle ile aç. Bu işlem koleksiyonun tamamını değiştirir; birleştirme yapmaz. CSV raporlama içindir, geri yüklenmez.

Bu sürüm tek bilgisayarda kullanılır. Otomatik senkronizasyon ve Firebase bağlantısı yoktur. DNA, dizi, plazmid ve gen modülleri henüz yoktur. Klinik kayıtlar için örnek kodları kullan; hasta kimliği girme.

ENGLISH
Extract the ZIP into a permanent folder and open culture-collection.html in Chrome, Edge or Firefox. Define your own groups, add cultures and attach one or more stock vials to each culture. Use the English button to switch languages.

Records are kept in the browser database, not in the HTML file. Keep the same file location and browser. Export a JSON backup before renaming or moving the file, updating the app or clearing browser data. Copying the HTML does not copy records. Avoid private browsing.

Restore JSON on another computer using Backups > Restore JSON backup. Restore replaces the entire collection; it does not merge records. CSV is for reporting only. There is no cloud sync or Firebase connection. DNA, sequence, plasmid and gene modules are not included. Use sample codes instead of patient identifiers.

Feedback: https://github.com/ugurlab/culture-collection/issues
Instrument Sans font: see FONT-LICENSE.txt.
