Culture Collection 1.1
Desk & Bench — Ugur Comlekcioglu

GETTING STARTED
1. Extract the ZIP into a permanent folder.
2. Open culture-collection.html in Chrome, Edge or Firefox.
3. On the Groups tab, add your own groups (for example clinical, wastewater, textile factory).
4. Add a culture, then attach one or more stock vials to it.
5. Download a JSON backup regularly from the Backups tab.

WHERE YOUR DATA IS STORED
Records are kept in the database of the browser you open the file in, not in the HTML file.
Keep using the same file location and the same browser. Download a JSON backup before you
move or rename the file, update the app or clear browser data. Copying the HTML file does not
copy your records. Do not use private browsing windows.

MOVING TO ANOTHER COMPUTER
Open the app on the new computer and use Backups > Restore JSON backup. Restoring replaces the
whole collection; it does not merge records. CSV files are for reports only and cannot be restored.

REMINDERS
- Vials prepared more than 6 months ago are marked "Over 6 months" and listed on the Overview
  tab so you can check their viability.
- If your last JSON backup is more than 6 months old, a reminder appears at the top of the app.

NOT INCLUDED IN THIS VERSION
There is no cloud sync or Firebase connection. DNA, sequence, plasmid and gene modules are not
included. Use sample codes instead of patient identifiers.

Feedback: https://github.com/ugurlab/culture-collection/issues
Instrument Sans font: see FONT-LICENSE.txt.

CHANGES IN 1.1
- English only.
- Search ignores accents and dotted/dotless i (for example "izmir" finds "İzmir").
- Stock search also covers temperature, quantity, preparation date and notes.
- Cultures and stock vials can be deleted.
- Warning when a position is already used by another vial.
- Six-month reminders for old stock vials and for backups.
